# MAX AI — Real AI Version

This is NOT a fake chat UI. The browser sends messages to `server.js`, and the server sends them to an OpenAI model using the Responses API.

## Files

- `public/index.html` — MAX AI interface
- `server.js` — secure backend / AI connection
- `package.json` — required packages
- `.env.example` — environment-variable example

## Run

1. Install Node.js.
2. Open a terminal in this folder.
3. Run:
   npm install
4. Create a file named `.env`.
5. Copy the values from `.env.example` into `.env`.
6. Put your OpenAI API key in `OPENAI_API_KEY`.
7. Run:
   npm start
8. Open:
   http://localhost:3000

IMPORTANT: Never put the API key inside `index.html` or publish it in frontend JavaScript.

The default model is `gpt-6-luna`. You can change `OPENAI_MODEL` in `.env` to another model available to your API account.
