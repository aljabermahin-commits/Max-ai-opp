import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.OPENAI_API_KEY) {
  console.warn("WARNING: OPENAI_API_KEY is not set.");
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname, "public")));

const MAX_INSTRUCTIONS = `
You are MAX AI, a helpful general-purpose AI assistant.

LANGUAGE:
- Answer in the same language the user uses.
- If the user writes Bangla, answer naturally in Bangla.
- If the user writes English, answer in English.
- If the user mixes Bangla and English, use a natural mix unless the user asks for one language.

STYLE:
- Answer the user's question directly.
- Do not say you are only a demo or frontend.
- Be clear, useful and concise by default.
- For coding questions, provide working code and explain the important parts.
- If a question needs current information and web access is not available, clearly say that you cannot verify live information.
- Never invent facts when you are uncertain.
- Follow safety requirements and do not provide harmful instructions.
`;

app.post("/api/chat", async (req,res)=>{
  try{
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    if(!messages.length){
      return res.status(400).json({error:"No message was provided."});
    }

    // Keep requests reasonably sized.
    const recent = messages.slice(-30).map(m=>({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0,12000)
    }));

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      instructions: MAX_INSTRUCTIONS,
      input: recent
    });

    res.json({answer: response.output_text || "I could not generate an answer."});
  }catch(error){
    console.error(error);
    res.status(500).json({
      error: error?.message || "MAX AI could not reach the AI model."
    });
  }
});

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(port,()=>{
  console.log(`MAX AI is running on http://localhost:${port}`);
});
